TODO: add information about contributions of team member(s)

Team member:
Gigi Wang (ywang580)
Cecelia Shuai (xshuai3)

Both work together on MS1
