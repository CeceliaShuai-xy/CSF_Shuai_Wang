TODO: add information about contributions of team member(s)

Team member:
Gigi Wang (ywang580)
Cecelia Shuai (xshuai3)

MS1: both members worked together in person and contributed equally.

MS2: 
Both group members splitted the functions and helped with each other's debugging:
    Gigi: uint256_create_from_hex, uint256_add, 
    Cecelia: uint256_format_as_hex, uint256_sub, uint256_mul
Helper functions:
    Gigi: uint64_to_binary, uint256_leftshift
    Cecelia: UInt256_to_twos_complement, uint256_bit_is_set, unit tests
And both contributed equally in discussion and styling.

